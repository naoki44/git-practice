# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '8175c31147dc6ffa1017fabb6d59e190157141fdcd461c4978e9f6cdeb54e64864ef63b9e8f10a093c6e0a0b43fdddcba92c77fb6c50457d2f8bfd7d9fe4f240'